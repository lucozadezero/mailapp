sample queries

```
# Write your query or mutation here

mutation Signup {
  signUp(args:{email: "abc@gmail.com", password: "holaholacocacola"}){
    email
  }
}

mutation Login {
  logIn(email: "abc@gmail.com", password: "holaholacocacola"){
    email
  }
}

query User {
  user{
    email
  }
}

mutation Logout {
  logOut
}

```
