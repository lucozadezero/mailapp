rm -rf /var/www/html
cp -r html /var/www/
systemctl restart nginx
cd backend
cp .env dist/.env
pm2 start -i max dist/server.js
pm2 save
pm2 startup
curl 'http://localhost:4000/emailapp/api/graphql' -H 'Accept-Encoding: gzip, deflate, br' -H 'Content-Type: application/json' -H 'Accept: application/json' -H 'Connection: keep-alive' -H 'DNT: 1' -H 'Origin: http://localhost:4000/amailapp/graphql' --data-binary '{"query":"# Write your query or mutation here\nmutation Signup {\n  signUp(args:{\n    email: \"admin@emailapp.com\",\n    password: \"qqaazz11__@\"\n  }){\n    email\n  }\n}"}' --compressed
mongo localhost:27017/emailapp --eval 'db.users.update({"email": "admin@emailapp.com"}, {$set: {"level": "Admin"}})'
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo "Setup Complete"
echo "Email is: admin@emailapp.com"
echo "password: qqaazz11__@"
